﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OfficeOpenXml;
using System.Text;
using Testowy.Models;

namespace Testowy.Controllers
{
    public class ExportController : Controller
    {
        private readonly TestDbContext _context;

        public ExportController(TestDbContext context)
        {
            _context = context;
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> ExportData(string fileType)
        {
            var klienci = await _context.Klienci.ToListAsync();

            if (!klienci.Any())
            {
                TempData["Error"] = "Brak danych do eksportu";
                return RedirectToAction("Index");
            }

            if (fileType == "CSV")
            {
                return await ExportToCsv(klienci);
            }
            else if (fileType == "XLSX")
            {
                return await ExportToExcel(klienci);
            }

            TempData["Error"] = "Nieprawidłowy format pliku";
            return RedirectToAction("Index");
        }

        private async Task<IActionResult> ExportToCsv(List<Klient> klienci)
        {
            var builder = new StringBuilder();

            // Dodaj nagłówek
            builder.AppendLine("id,imie,nazwisko,pesel,rok_urodzenia,plec");

            // Dodaj dane
            foreach (var klient in klienci)
            {
                builder.AppendLine($"{klient.Id},{klient.Name},{klient.Surname},{klient.PESEL},{klient.BirthYear},{klient.Plec}");
            }

            byte[] fileBytes = Encoding.UTF8.GetBytes(builder.ToString());
            string fileName = $"klienci_{DateTime.Now:yyyyMMdd_HHmmss}.csv";

            return File(fileBytes, "text/csv", fileName);
        }

        private async Task<IActionResult> ExportToExcel(List<Klient> klienci)
        {
            using (var package = new ExcelPackage())
            {
                var worksheet = package.Workbook.Worksheets.Add("Klienci");

                // Dodaj nagłówki
                worksheet.Cells[1, 1].Value = "ID";
                worksheet.Cells[1, 2].Value = "Imię";
                worksheet.Cells[1, 3].Value = "Nazwisko";
                worksheet.Cells[1, 4].Value = "PESEL";
                worksheet.Cells[1, 5].Value = "Rok urodzenia";
                worksheet.Cells[1, 6].Value = "Płeć";

                // Dodaj dane
                int row = 2;
                foreach (var klient in klienci)
                {
                    worksheet.Cells[row, 1].Value = klient.Id;
                    worksheet.Cells[row, 2].Value = klient.Name;
                    worksheet.Cells[row, 3].Value = klient.Surname;
                    worksheet.Cells[row, 4].Value = klient.PESEL;
                    worksheet.Cells[row, 5].Value = klient.BirthYear;
                    worksheet.Cells[row, 6].Value = klient.Plec;
                    row++;
                }

                // Formatowanie
                worksheet.Cells[worksheet.Dimension.Address].AutoFitColumns();

                // Styl nagłówków
                var headerRow = worksheet.Row(1);
                headerRow.Style.Font.Bold = true;

                string fileName = $"klienci_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx";
                return File(package.GetAsByteArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
            }
        }
    }
}