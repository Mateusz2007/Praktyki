﻿using Microsoft.AspNetCore.Mvc;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Testowy.Models;

namespace Testowy.Controllers
{
    public class ImportController : Controller
    {
        private readonly TestDbContext _context;

        public ImportController(TestDbContext context)
        {
            _context = context;
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Import(IFormFile file, string fileType)
        {
            if (file == null || file.Length == 0)
            {
                TempData["Error"] = "Proszę wybrać plik";
                return View("Index");
            }

            // Sprawdzenie rozszerzenia pliku
            var extension = Path.GetExtension(file.FileName).ToLowerInvariant();
            if ((fileType == "CSV" && extension != ".csv") ||
                (fileType == "XLSX" && extension != ".xlsx"))
            {
                TempData["Error"] = $"Nieprawidłowy format pliku dla wybranego typu: {fileType}";
                return View("Index");
            }

            try
            {
                var klienci = new List<Klient>();

                using (var stream = new MemoryStream())
                {
                    await file.CopyToAsync(stream);
                    stream.Position = 0;

                    if (fileType == "CSV")
                    {
                        klienci = await ImportFromCsv(stream);
                    }
                    else if (fileType == "XLSX")
                    {
                        klienci = await ImportFromExcel(stream);
                    }

                    if (!klienci.Any())
                    {
                        TempData["Error"] = "Nie znaleziono żadnych danych do importu";
                        return View("Index");
                    }

                    await _context.Klienci.AddRangeAsync(klienci);
                    await _context.SaveChangesAsync();

                    TempData["Success"] = $"Pomyślnie zaimportowano {klienci.Count} klientów";
                    return RedirectToAction("Index", "Test");
                }
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Błąd podczas importu: {ex.Message}";
                return View("Index");
            }
        }

        private async Task<List<Klient>> ImportFromCsv(MemoryStream stream)
        {
            var klienci = new List<Klient>();
            using (var reader = new StreamReader(stream))
            {
                // Pomijamy wiersz nagłówka
                await reader.ReadLineAsync();
                int lineNumber = 1;

                while (!reader.EndOfStream)
                {
                    lineNumber++;
                    var line = await reader.ReadLineAsync();
                    if (string.IsNullOrEmpty(line)) continue;

                    var values = line.Split(',');

                    if (values.Length < 6)
                    {
                        throw new Exception($"Nieprawidłowa liczba kolumn w linii {lineNumber}");
                    }

                    var klient = await ValidateAndCreateKlient(
                        values[1].Trim(),    // imię
                        values[2].Trim(),    // nazwisko
                        values[3].Trim(),    // PESEL
                        values[4].Trim(),    // rok urodzenia
                        values[5].Trim(),    // płeć
                        lineNumber
                    );

                    klienci.Add(klient);
                }
            }
            return klienci;
        }

        private async Task<List<Klient>> ImportFromExcel(MemoryStream stream)
        {
            var klienci = new List<Klient>();
            using (var package = new ExcelPackage(stream))
            {
                var worksheet = package.Workbook.Worksheets[0];
                var rowCount = worksheet.Dimension?.Rows;

                if (rowCount == null || rowCount < 2)
                {
                    throw new Exception("Plik jest pusty lub nie zawiera danych");
                }

                for (int row = 2; row <= rowCount.Value; row++)
                {
                    // Sprawdzamy czy wiersz nie jest pusty
                    if (worksheet.Cells[row, 2].Value == null &&
                        worksheet.Cells[row, 3].Value == null)
                    {
                        continue;
                    }

                    var klient = await ValidateAndCreateKlient(
                        worksheet.Cells[row, 2].Value?.ToString().Trim(), // imię
                        worksheet.Cells[row, 3].Value?.ToString().Trim(), // nazwisko
                        worksheet.Cells[row, 4].Value?.ToString().Trim(), // PESEL
                        worksheet.Cells[row, 5].Value?.ToString().Trim(), // rok urodzenia
                        worksheet.Cells[row, 6].Value?.ToString().Trim(), // płeć
                        row
                    );

                    klienci.Add(klient);
                }
            }
            return klienci;
        }

        private async Task<Klient> ValidateAndCreateKlient(string name, string surname, string pesel,
            string birthYearStr, string plecStr, int rowNumber)
        {
            // Sprawdzenie wymaganych pól
            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(surname))
            {
                throw new Exception($"Brakujące dane w wierszu {rowNumber}");
            }

            // Walidacja PESEL
            if (string.IsNullOrEmpty(pesel) || pesel.Length != 11 || !pesel.All(char.IsDigit))
            {
                throw new Exception($"Błędny format PESEL w wierszu {rowNumber}");
            }

            // Walidacja roku urodzenia
            if (!int.TryParse(birthYearStr, out int birthYear))
            {
                throw new Exception($"Błędny format roku urodzenia w wierszu {rowNumber}");
            }

            // Walidacja płci
            if (!int.TryParse(plecStr, out int plec) || (plec != 0 && plec != 1))
            {
                throw new Exception($"Błędny format płci w wierszu {rowNumber}. Dozwolone wartości: 0 (kobieta) lub 1 (mężczyzna)");
            }

            return new Klient
            {
                Name = name,
                Surname = surname,
                PESEL = pesel,
                BirthYear = birthYear,
                Plec = plec
            };
        }
    }
}
