﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;
using Testowy.Models;
using Testowy;

public class TestController : Controller
{
    private readonly TestDbContext _context;

    public TestController(TestDbContext context)
    {
        _context = context;
    }

    public IActionResult Index()
    {
        try
        {
            var klienci = _context.Klienci.ToList();
            if (klienci == null)
            {
                Console.WriteLine("Lista klientów jest null");
            }
            else
            {
                Console.WriteLine($"Znaleziono {klienci.Count} klientów");
            }
            return View(klienci);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Błąd: {ex.Message}");
            Console.WriteLine($"Stack trace: {ex.StackTrace}");
            throw;
        }
    }
    public IActionResult Create()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Create(Klient klient)
    {
        if (ModelState.IsValid)
        {
            Console.WriteLine($"Otrzymana wartość płci: {klient.Plec}");

            try
            {
                _context.Klienci.Add(klient);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Błąd podczas zapisu: {ex.Message}");
                ModelState.AddModelError("", "Wystąpił błąd podczas zapisu do bazy danych.");
            }
        }
        return View(klient);
    }
    
    public IActionResult Edit(int id)
    {
        var klient = _context.Klienci.Find(id);
        if(klient == null)
        {
            return NotFound();
        }
        return View(klient);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Edit(int id, Klient klient)
    {
        if(id != klient.Id)
        {
            return BadRequest("Nieprawidłowy identyfikator klienta");
        }
        if (ModelState.IsValid)
        {
            Console.WriteLine($"Otrzymana wartość płci: {klient.Plec}");

            try
            {
                _context.Update(klient);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            catch (DbUpdateException ex)
            {
                Console.WriteLine($"Błąd podczas próby aktualizacji danych: {ex.Message}");
                ModelState.AddModelError("", "Wystąpił błąd podczas aktualizacji danych w bazie danych.");
            }
        }
        return View(klient);
    }

    
    private bool IsValidPesel(string pesel)
    {
        //Kod sprawdzający poprawność pesela
        if (string.IsNullOrEmpty(pesel) || pesel.Length != 11)
            return false;

        int[] weights = { 1, 3, 7, 9, 1, 3, 7, 9, 1, 3 };
        int sum = 0;

        for (int i = 0; i < 10; i++)
        {
            if (!int.TryParse(pesel[i].ToString(), out int digit))
                return false;
            sum += digit * weights[i];
        }

        int checksum = (10 - (sum % 10)) % 10;
        return int.Parse(pesel[10].ToString()) == checksum;
    }

    [HttpGet]
    public IActionResult Delete(int id)
    {
        try
        {
            var klient = _context.Klienci.Find(id);
            if (klient == null)
            {
                return NotFound();
            }

            _context.Klienci.Remove(klient);
            _context.SaveChanges();

            return RedirectToAction(nameof(Index));
        }
        catch (Exception ex)
        {
            return StatusCode(500, "Wystąpił błąd podczas usuwania klienta.");
        }
    }
}