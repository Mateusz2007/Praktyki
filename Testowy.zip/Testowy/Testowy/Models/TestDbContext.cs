﻿using Microsoft.EntityFrameworkCore;
using Testowy.Models;

namespace Testowy
{
    public class TestDbContext : DbContext
    {
        public TestDbContext(DbContextOptions<TestDbContext> options)
            : base(options) { }

        public DbSet<Klient> Klienci { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Klient>(entity =>
            {
                entity.ToTable("Klienci");
            });
        }
    }
}
