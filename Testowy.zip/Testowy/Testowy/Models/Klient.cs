﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Testowy.Models
{
    public class Klient
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Pole Imię jest wymagane")]
        [Display(Name = "Imię")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Pole Nazwisko jest wymagane")]
        [Display(Name = "Nazwisko")]
        public string Surname { get; set; }

        [Required(ErrorMessage = "Pole PESEL jest wymagane")]
        [StringLength(11, MinimumLength = 11, ErrorMessage = "PESEL musi mieć 11 cyfr")]
        [RegularExpression(@"^\d{11}$", ErrorMessage = "PESEL może zawierać tylko cyfry")]
        public string PESEL { get; set; }

        [Display(Name = "Rok urodzenia")]
        public int BirthYear { get; set; }


        [Column("plec")]
        [Display(Name = "Płeć")]
        public int Plec { get; set; }
    }
}
